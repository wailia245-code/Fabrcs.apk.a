Fabrics v17.7.7 — RECOVERED SYSTEM BUNDLE

This bundle was reconstructed from the APK supplied in the conversation.
Package: com.fabrics.app
versionCode: 1777
versionName: 17.7.7
compileSdk: 34
Target SDK: 34

Important:
- The HTML payload is the exact bytes of the APK's assets/www/index.html, copied to:
  app/src/main/assets/v17.7.7-PRODUCTION.html
- The recovered APK is included separately in the outer delivery ZIP.
- This is a recovered project bundle, not a claim that a new APK was rebuilt from this ZIP.
- The three native files currently recovered from the APK are Java files: MainActivity.java, PrintBridge.java, ShareBridge.java.
