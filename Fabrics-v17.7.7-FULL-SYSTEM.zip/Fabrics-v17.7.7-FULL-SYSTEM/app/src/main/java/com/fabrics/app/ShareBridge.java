package com.fabrics.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;

public class ShareBridge {
    private final Context context;

    public ShareBridge(Context context) {
        this.context = context;
    }

    @JavascriptInterface
    public void shareFile(String base64Data, String fileName, String mimeType, String title) {
        try {
            byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
            File cacheDir = context.getCacheDir();
            File shareDir = new File(cacheDir, "shared_files");
            if (!shareDir.exists()) shareDir.mkdirs();
            File file = new File(shareDir, fileName);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(data);
            fos.close();

            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType(mimeType != null ? mimeType : getMimeType(fileName));
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, title != null ? title : fileName);
            shareIntent.putExtra(Intent.EXTRA_TITLE, title != null ? title : fileName);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            shareIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

            Intent chooser = Intent.createChooser(shareIntent, title != null ? title : "مشاركة");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            if (context instanceof Activity) ((Activity) context).startActivity(chooser);
            else context.startActivity(chooser);
        } catch (Exception e) {
            e.printStackTrace();
            notifyJsError(e.getMessage());
        }
    }

    @JavascriptInterface
    public void shareText(String text, String title) {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, text);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, title);
            Intent chooser = Intent.createChooser(shareIntent, title);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(chooser);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private String getMimeType(String fileName) {
        String extension = MimeTypeMap.getFileExtensionFromUrl(fileName);
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        return mime != null ? mime : "*/*";
    }

    private void notifyJsError(String errorMsg) {
        if (context instanceof Activity) {
            ((Activity) context).runOnUiThread(() ->
                Toast.makeText(context, "خطأ: " + errorMsg, Toast.LENGTH_SHORT).show()
            );
        }
    }
}