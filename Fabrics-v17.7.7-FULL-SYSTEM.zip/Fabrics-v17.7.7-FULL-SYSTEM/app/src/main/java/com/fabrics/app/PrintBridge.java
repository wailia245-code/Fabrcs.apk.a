package com.fabrics.app;

import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class PrintBridge {
    private final Context context;

    public PrintBridge(Context context) {
        this.context = context;
    }

    @JavascriptInterface
    public void printHtml(final String html, final String jobName) {
        final android.app.Activity activity = (android.app.Activity) context;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    WebView printView = new WebView(context);
                    printView.getSettings().setJavaScriptEnabled(true);
                    printView.getSettings().setDomStorageEnabled(true);

                    printView.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(WebView view, String url) {
                            PrintManager printManager = (PrintManager) context.getSystemService(Context.PRINT_SERVICE);
                            String job = (jobName != null && !jobName.isEmpty()) ? jobName : "FabricsDocument";
                            PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(job);
                            PrintAttributes attributes = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setResolution(new PrintAttributes.Resolution("pdf", "pdf", 600, 600))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                            printManager.print(job, adapter, attributes);
                        }
                    });
                    printView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(context, "خطأ الطباعة: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}