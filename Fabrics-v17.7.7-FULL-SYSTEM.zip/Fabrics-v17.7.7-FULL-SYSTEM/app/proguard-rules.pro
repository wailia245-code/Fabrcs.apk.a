# Fabrics release rules
